This package contains functions for the IS 415 Data Analytics/Machine Learning class at BYU
The functions included are
    calculateUnivariantStatsViz 
    calculateBivariantStatsViz
    assumptions
    calculateMLRandMetrics

The calculateUnivariantStatsViz function only has one parameter of a pandas dataframe

The rest of the functions require a pandas dataframe and a lable (y-variable)